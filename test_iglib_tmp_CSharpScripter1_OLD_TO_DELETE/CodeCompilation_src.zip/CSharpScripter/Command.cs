using System;

namespace CSharpScripter
{
	/// <summary>
	/// Zusammenfassung f�r Command.
	/// </summary>
	public interface Command
	{
		void Execute();
	}
}
